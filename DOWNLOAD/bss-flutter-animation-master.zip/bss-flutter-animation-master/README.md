# Demo Animation Flutter

### Video: https://www.youtube.com/watch?v=l1DoUFsEQnU
### Guide: https://medium.com/@duytq94/restaurant-animation-with-flutter-cbe704b4e20f

## Screenshots:

<img src="https://github.com/beesightsoft/bss-flutter-animation/blob/master/ScreenShots/RestaurantAnimation.gif?raw=true" height="30%" width="30%">
<img src="https://github.com/beesightsoft/bss-flutter-animation/blob/master/ScreenShots/SimpleAnimation.gif?raw=true" height="30%" width="30%">
