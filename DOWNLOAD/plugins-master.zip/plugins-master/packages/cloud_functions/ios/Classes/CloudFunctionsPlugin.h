#import <Flutter/Flutter.h>

@interface CloudFunctionsPlugin : NSObject<FlutterPlugin>
@end
