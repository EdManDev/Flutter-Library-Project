# firebase_auth_example

[![pub package](https://img.shields.io/pub/v/firebase_auth.svg)](https://pub.dartlang.org/packages/firebase_auth)

Demonstrates how to use the firebase_auth plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
