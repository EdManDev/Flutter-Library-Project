## 0.0.4

* Formatted code, updated comments, and removed unnecessary files.

## 0.0.3

* Updated Gradle tooling to match Android Studio 3.1.2.

## 0.0.2

* Added HttpMetric for monitoring for specific network requests.

## 0.0.1

* Initial Release.
