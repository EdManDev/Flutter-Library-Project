#import <Flutter/Flutter.h>

@interface FLTFirebasePerformancePlugin : NSObject<FlutterPlugin>
@end
