#import <Flutter/Flutter.h>

@interface FirebaseMlVisionPlugin : NSObject<FlutterPlugin>
@end
