part of firebase_remote_config;

/// LastFetchStatus defines the possible status values of the last fetch.
enum LastFetchStatus { success, failure, throttled, noFetchYet }
