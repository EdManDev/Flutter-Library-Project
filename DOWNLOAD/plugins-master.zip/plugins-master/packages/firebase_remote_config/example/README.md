# firebase_remote_config_example

Demonstrates how to use the firebase_remote_config plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
