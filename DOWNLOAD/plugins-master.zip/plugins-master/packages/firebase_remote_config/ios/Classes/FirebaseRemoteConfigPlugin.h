#import <Flutter/Flutter.h>

@interface FirebaseRemoteConfigPlugin : NSObject<FlutterPlugin>
@end
