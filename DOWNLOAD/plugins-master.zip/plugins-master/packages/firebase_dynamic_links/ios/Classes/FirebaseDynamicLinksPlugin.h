#import <Flutter/Flutter.h>

@interface FLTFirebaseDynamicLinksPlugin : NSObject<FlutterPlugin>
@end
