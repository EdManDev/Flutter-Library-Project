#import <Flutter/Flutter.h>

@interface CameraPlugin : NSObject<FlutterPlugin>
@end
