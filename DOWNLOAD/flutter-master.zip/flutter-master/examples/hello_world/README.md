```
# To run the Hello World demo:
flutter run

# To run the Hello World demo showing Arabic:
flutter run lib/arabic.dart
```
