Flutter is Google’s mobile UI framework for crafting high-quality native
interfaces on iOS and Android in record time. Flutter works with existing code,
is used by developers and organizations around the world, and is free and open
source.

### Documentation

* **Main site: [flutter.io](https://flutter.io/)**
* [Install](https://flutter.io/setup/)
* [Get started](https://flutter.io/getting-started/)
* [Contribute](CONTRIBUTING.md)
