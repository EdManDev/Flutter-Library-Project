/// [Flutter platform integration APIs for Android.](https://docs.flutter.io/javadoc/)
library Android;
