Automated Flutter integration test suites. Each suite consists of a complete
Flutter app and a `flutter_driver` specification that drives tests from the UI.

Intended for use with devicelab.
